const String constAssignmentTableName = 'assignments';
const String constAssignmentName = 'assignment_Name';
const String constAssignmentDate = 'assignment_date';
const String constAssignmentCategory = 'assignment_Category';
const String constAssignmentDone = 'assignment_Done';
const String constAssignmentDescreption = 'assignment_Descreption';

const String constSubAssignmentTableName = 'Sub_Assignments';
const String constSubAssignmentName = 'SubAssignments_Name';
const String constSubAssignmentDate = 'SubAssignments_Date';
const String constSubAssignmentDone = 'SubAssignments_Done';
const String constAssignmentId = 'Assignment_Id';

//const String assignmentName = 'assignment_Name';
